SofiStore Addis Pro
Open index.html in a browser. On iPhone Safari, use Share > Add to Home Screen.
Features: inventory, IMEI, supplier, warranty, sales, customers, expenses, weekly net profit, reports, JSON backup/restore.
Data is local to the browser/device in this version.
